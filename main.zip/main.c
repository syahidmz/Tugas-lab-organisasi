#include <stdio.h>

int main()
{
    int X, Y, A;

    printf ("Masukan Nilai X = " );
    scanf ("%i", &X);

    printf ("Masukan Nilai Y = " );
    scanf ("%i", &Y);

    A = X/Y;

    printf ("Hasil pembagiannya adalah = %i",A);
    return 0;
}
